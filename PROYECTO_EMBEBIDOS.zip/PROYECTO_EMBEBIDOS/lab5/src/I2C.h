/*
 * I2C.h
 *
 *  Created on: 13 dic 2023
 *      Author: Hezitzaile
 */

#ifndef I2C_H_
#define I2C_H_
#include "hal_data.h"
fsp_err_t init_i2c(void);
void initialice_LCD(void);
void clear_i2c(void);
fsp_err_t write_LCD(uint8_t mensaje[0x08],uint8_t fila[0x02]);




#endif /* I2C_H_ */
