/* generated configuration header file - do not edit */
#ifndef R_ICU_CFG_H_
#define R_ICU_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define ICU_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)

#ifdef __cplusplus
}
#endif
#endif /* R_ICU_CFG_H_ */
