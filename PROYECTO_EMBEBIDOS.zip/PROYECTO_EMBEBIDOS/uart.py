import serial
import time
import csv
import json
import paho.mqtt.publish as publish
from datetime import datetime

uart_baudrate = 115200
uart_serial = serial.Serial('COM4', uart_baudrate, timeout=10, 
                            parity=serial.PARITY_NONE, 
                            stopbits=serial.STOPBITS_ONE, 
                            bytesize=serial.EIGHTBITS)

topic = "pot"
hostname = "LAPTOP-5GLI95F2"  # Asegúrate de que este sea el host correcto

# Función para obtener el timestamp actual
def get_current_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Función para escribir en el archivo CSV en la ubicación especificada
def write_to_csv(data):
    with open('C:\\Users\\Zuhaitz Gabilondo\\Desktop\\PROYECTO_EMBEBIDOS\\datos_uart.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([data, get_current_timestamp()])

# Función para publicar el mensaje recibido vía MQTT
def publish_message(mensaje):
    mensaje_json = json.dumps({"timestamp": get_current_timestamp(), "value": mensaje})
    publish.single(topic=topic, payload=mensaje_json, qos=1, hostname=hostname)
    print("Mensaje publicado vía MQTT: " + mensaje_json)

x = 0;

if uart_serial.is_open:
    while True:
        size = uart_serial.inWaiting()
        if size:
            data = uart_serial.read(size)
            received_data_string = data.decode('utf-8')
            print(received_data_string)
            write_to_csv(received_data_string)
            if int(received_data_string) > 9000:
                if x == 0:
                    publish_message(received_data_string)  # Publicar el mensaje vía MQTT
                    x = 1
            else:
                x = 0
        else:
        
            time.sleep(1)

else:
    print('Puerto serie no abierto')
